package test;

import java.util.Scanner;

public class StudentRecordManagementSystem {

	 Node start;
	    

	    public StudentRecordManagementSystem() {
	        this.start = null;
	      
	    }
		public Node getNode(String name, int rollNumber, String course, double totalMarks) {
			Node newNode= new Node(name, rollNumber, course, totalMarks);
			
			Scanner input =new Scanner(System.in);
			
			newNode.rollNumber=input.nextInt();
			newNode.next=null;
			
			return newNode;
		}


	    public void insertRecord(String name, int rollNumber, String course, double totalMarks) {
	        Node newNode = new Node(name, rollNumber, course, totalMarks);

	    		
	    		if(start==null) {
	    			start=newNode;
	    		}
	    		else {
	    			Node temp =start;
	    			while(temp.next!=null) {
	    				temp=temp.next;
	    			}
	    			temp.next=newNode;
	    		}
	    }
	    public void searchRecord(int rollNumber) {
	        Node temp = start;
	        while (temp != null) {
	            if (temp.rollNumber == rollNumber) {
	                System.out.println("Record found: " + temp.name + " " + temp.rollNumber + " " + temp.course + " " + temp.totalMarks);
	                return;
	            }
	            temp = temp.next;
	        }
	        System.out.println("Record not found");
	    }
	

	    public void deleteRecord(int rollNumber) {
	        if (start == null) {
	            System.out.println("List is empty");
	        } else {
	            Node temp = start;
	            while (temp.next.next != null) {
	                if (temp.next.rollNumber == rollNumber) {
	                    temp.next = temp.next.next;
	                    return;
	                }
	                temp = temp.next;
	            }
	            if (temp.next.rollNumber == rollNumber) {
	                temp.next = null;
	            } else {
	                System.out.println("Record not found");
	            }
	        }
	    }
	
	    public void showRecord() {
	        Node temp = start;

	        while (temp != null) {
	            System.out.println(temp.name + " " + temp.rollNumber + " " + temp.course + " " + temp.totalMarks);
	            temp = temp.next;
	        }
	    }
}
