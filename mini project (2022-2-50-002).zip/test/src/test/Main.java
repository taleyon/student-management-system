package test;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 StudentRecordManagementSystem system = new StudentRecordManagementSystem();

	        Scanner scanner = new Scanner(System.in);

	        System.out.println("Enter the number of records to be created: ");
	        int numberOfRecords = scanner.nextInt();

	        for (int i = 0; i < numberOfRecords; i++) {
	            System.out.println("Enter the name of the student: ");
	            String name = scanner.next();

	            System.out.println("Enter the roll number of the student: ");
	            int rollNumber = scanner.nextInt();

	            System.out.println("Enter the course of the student: ");
	            String course = scanner.next();

	            System.out.println("Enter the total marks of the student: ");
	            double totalMarks = scanner.nextDouble();

	            system.insertRecord(name, rollNumber, course, totalMarks);
	        }
	        
	        System.out.println("The records are: ");
	        system.showRecord();
	        System.out.println("Enter the roll number to search: ");
	        int rollNumber = scanner.nextInt();

	        system.searchRecord(rollNumber);

	        System.out.println("Enter the roll number to delete: ");
	        int deleteRollNumber = scanner.nextInt();

	        system.deleteRecord(deleteRollNumber);
	        System.out.println("The records are: ");
	        system.showRecord();
	    }
	}